﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace Plugins.DocumentUpload
{
    public class AssignRecordToTeam_Workflow : CodeActivity
    {
        [Output("Is Owner Updated?")]
        [Default("False")]
        [RequiredArgument]
        public OutArgument<bool> IsOwnerUpdated { get; set; }
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            tracingService.Trace("Plugins.DocumentUpload.AssignRecordToTeam_Workflow");
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    EntityReference currentRecord = (EntityReference)context.InputParameters["Target"];

                    tracingService.Trace("Record Id [" + currentRecord.Id.ToString() + "]");

                    Entity documentUpload = service.Retrieve(currentRecord.LogicalName, currentRecord.Id, new ColumnSet(Tables.DocumentUpload.DocuTypeLookup));

                    if (documentUpload.Contains(Tables.DocumentUpload.DocuTypeLookup))
                    {
                        EntityReference docuTypeRef = documentUpload.GetAttributeValue<EntityReference>(Tables.DocumentUpload.DocuTypeLookup);

                        Entity docuType = service.Retrieve(docuTypeRef.LogicalName, docuTypeRef.Id, new ColumnSet(Tables.DocumentType.Name));

                        #region Fetch the Team Guid
                        var teamsquery = new QueryExpression(Tables.Team.LogicalName);
                        teamsquery.ColumnSet.AddColumn(Tables.Team.PrimaryKey);
                        teamsquery.Criteria.AddCondition(Tables.Team.Name, ConditionOperator.Equal, docuType[Tables.DocumentType.Name] + " - Searchable");

                        EntityCollection teamsColl = service.RetrieveMultiple(teamsquery);

                        if (teamsColl.Entities.Count == 0)
                        {
                            tracingService.Trace("Team not found. Exit");

                            return;
                        }

                        Guid teamGuid = teamsColl.Entities[0].Id;

                        tracingService.Trace("Team Guid: " + teamGuid);

                        #endregion

                        #region Assign record to the team

                        Entity currentRecordUpdate = new Entity(currentRecord.LogicalName, currentRecord.Id);

                        currentRecordUpdate["ownerid"] = new EntityReference(Tables.Team.LogicalName, teamGuid);

                        service.Update(currentRecordUpdate);

                        tracingService.Trace("Record has been assigned to the team");

                        #endregion

                        IsOwnerUpdated.Set(executionContext, true);
                    }
                    else
                    {
                        tracingService.Trace("Document Type is blank. Exit");
                    }
                }
                else
                {
                    tracingService.Trace("Not entity reference object. Exit");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message + " : " + ex.InnerException);
            }

        }
    }
}
