﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;


namespace Plugins.DocumentUpload
{
    public class CheckIfUserInTeams : CodeActivity
    {
        [Output("Is User in Teams?")]
        [Default("False")]
        [RequiredArgument]
        public OutArgument<bool> IsUserInTeams { get; set; }
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            tracingService.Trace("Plugins.DocumentUpload.CheckIfUserInTeams");

            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    EntityReference currentRecord = (EntityReference)context.InputParameters["Target"];

                    tracingService.Trace("Record Id [" + currentRecord.Id.ToString() + "]");

                    Entity documentUpload = service.Retrieve(currentRecord.LogicalName, currentRecord.Id, new ColumnSet(Tables.DocumentUpload.DocuTypeLookup));

                    if (documentUpload.Contains(Tables.DocumentUpload.DocuTypeLookup))
                    {
                        EntityReference docuTypeRef = documentUpload.GetAttributeValue<EntityReference>(Tables.DocumentUpload.DocuTypeLookup);

                        Entity docuType = service.Retrieve(docuTypeRef.LogicalName, docuTypeRef.Id, new ColumnSet(Tables.DocumentType.Name));

                        tracingService.Trace("Document Type Id [" + docuType.Id.ToString() + "]");

                        // Get the teams of the docuType
                        var query = new QueryExpression("team")
                        {
                            ColumnSet = new ColumnSet("teamid", "name"),
                            LinkEntities =
                                {
                                    new LinkEntity("team", "new_new_documenttypeprivilegesconfi_team_nn", "teamid", "teamid", JoinOperator.Inner)
                                    {
                                        LinkEntities =
                                        {
                                            new LinkEntity(
                                                "new_new_documenttypeprivilegesconfi_team_nn",
                                                "new_documenttypeprivilegesconfi",
                                                "new_documenttypeprivilegesconfiid",
                                                "new_documenttypeprivilegesconfiid",
                                                JoinOperator.Inner)
                                            {
                                                LinkCriteria =
                                                {
                                                    Conditions =
                                                    {
                                                        new ConditionExpression("new_documenttype", ConditionOperator.Equal, docuType.Id)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                        };

                        EntityCollection teamsColl = service.RetrieveMultiple(query);

                        if (teamsColl.Entities.Count > 0)
                        {
                            tracingService.Trace("No of Teams found :" + teamsColl.Entities.Count);

                            var fetchXml = $@"<?xml version='1.0' encoding='utf-16'?>
                                                <fetch>
                                                  <entity name='team'>
                                                    <attribute name='teamid' />
                                                    <filter>
                                                      <condition attribute='teamid' operator='in'>";

                            string values = string.Empty;

                            foreach (Entity team in teamsColl.Entities)
                            {
                                values = "<value>" + team.Id.ToString() + "</value>";
                            }

                            fetchXml = fetchXml + values;

                            fetchXml = fetchXml + $@"</condition>
                                                    </filter>
                                                    <link-entity name='teammembership' from='teamid' to='teamid' intersect='true'>
                                                      <link-entity name='systemuser' from='systemuserid' to='systemuserid' intersect='true'>
                                                        <filter type='and'>
                                                          <condition attribute='systemuserid' operator='eq' value='" + context.UserId.ToString() + @"' />
                                                        </filter>
                                                      </link-entity>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";

                            tracingService.Trace(String.Format("FetchXML: {0} ", fetchXml));

                            EntityCollection givenTeams = service.RetrieveMultiple(new FetchExpression(fetchXml));

                            Boolean UserInTeam = (givenTeams.Entities.Count > 0);

                            tracingService.Trace(String.Format("Is User in Teams: {0} ", UserInTeam));

                            IsUserInTeams.Set(executionContext, UserInTeam);
                        }
                        else
                        {
                            tracingService.Trace("No teams found.");
                        }
                    }
                    else
                    {
                        tracingService.Trace("Document Type is blank. Exit");
                    }
                }
                else
                {
                    tracingService.Trace("Not entity reference object. Exit");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message + " : " + ex.InnerException);
            }
        }
    }
}
