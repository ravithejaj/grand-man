﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Plugins;

namespace Plugins.DocumentUpload
{
    public class AssignRecordToTeam : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            tracingService.Trace("Plugins.DocumentUpload.AssignRecordToTeam");

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity currentRecord = (Entity)context.InputParameters["Target"];

                tracingService.Trace("Record Id [" + currentRecord.Id.ToString() + "]");

                if (currentRecord.Contains(Tables.DocumentUpload.DocuTypeLookup))
                {
                    EntityReference docuTypeRef = currentRecord.GetAttributeValue<EntityReference>(Tables.DocumentUpload.DocuTypeLookup);

                    Entity docuType = service.Retrieve(docuTypeRef.LogicalName, docuTypeRef.Id, new ColumnSet(Tables.DocumentType.Name));

                    #region Fetch the Team Guid
                    var teamsquery = new QueryExpression(Tables.Team.LogicalName);
                    teamsquery.ColumnSet.AddColumn(Tables.Team.PrimaryKey);
                    teamsquery.Criteria.AddCondition(Tables.Team.Name, ConditionOperator.Equal, docuType[Tables.DocumentType.Name]);

                    EntityCollection teamsColl = service.RetrieveMultiple(teamsquery);

                    if (teamsColl.Entities.Count == 0)
                    {
                        tracingService.Trace("Team not found. Exit");

                        return;
                    }

                    Guid teamGuid = teamsColl.Entities[0].Id;

                    tracingService.Trace("Team Guid: " + teamGuid);

                    #endregion

                    #region Assign record to the team

                    Entity currentRecordUpdate = new Entity(currentRecord.LogicalName, currentRecord.Id);

                    currentRecordUpdate["ownerid"] = new EntityReference(Tables.Team.LogicalName, teamGuid);

                    service.Update(currentRecordUpdate);

                    #endregion
                }
            }
        }
    }
}
