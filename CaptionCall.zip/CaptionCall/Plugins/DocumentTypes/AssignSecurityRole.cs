﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;


namespace Plugins.DocumentTypes
{
    public class AssignSecurityRole : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            tracingService.Trace("Plugins.DocumentTypes.AssignSecurityRole");

            if (context.MessageName == "Associate" || context.MessageName == "Disassociate") //
            {

                tracingService.Trace("Message : " + context.MessageName);

                if (context.InputParameters.Contains("Relationship"))
                {
                    Relationship rel = (Relationship)context.InputParameters["Relationship"];

                    tracingService.Trace("Relationship : " + rel.SchemaName);

                    if (rel.SchemaName != Tables.Relationships.TeamRelationship)
                    {
                        return;
                    }

                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                    {
                        // Get the Document Type record
                        EntityReference configRef = (EntityReference)context.InputParameters["Target"];

                        EntityReferenceCollection relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;

                        EntityReference team = relatedEntities[0];

                        #region Fetch Role and BU info

                        #region Query BU and Role info
                        var query = new QueryExpression(Tables.DocumentTypePrivilege.LogicalName);
                        query.ColumnSet.AddColumns(Tables.DocumentTypePrivilege.DocumentTypeLookup, Tables.DocumentTypePrivilege.SecurityRoleLookup);
                        query.Criteria.AddCondition(Tables.DocumentTypePrivilege.PrimaryKey, ConditionOperator.Equal, configRef.Id);
                        var doctypeAilas = query.AddLink("new_documenttype", "new_documenttype", "new_documenttypeid", JoinOperator.LeftOuter);
                        doctypeAilas.EntityAlias = "doctypeAilas";
                        doctypeAilas.Columns.AddColumns("new_name", "new_documenttypeid");
                        var roleAilas = query.AddLink("role", "new_securityrole", "roleid", JoinOperator.LeftOuter);
                        roleAilas.EntityAlias = "roleAilas";
                        roleAilas.Columns.AddColumns("name", "roleid");
                        EntityCollection entityColl = service.RetrieveMultiple(query);
                        #endregion

                        if (entityColl.Entities.Count > 0)
                        {
                            string docuTypeName = (string)((AliasedValue)entityColl.Entities[0]["doctypeAilas.new_name"]).Value;

                            string securityRoleName = (string)((AliasedValue)entityColl.Entities[0]["roleAilas.name"]).Value;

                            #region Get BU Guid by Name
                            var buquery = new QueryExpression(Tables.BusniessUnit.LogicalName);
                            buquery.ColumnSet.AddColumn(Tables.BusniessUnit.PrimaryKey);
                            buquery.Criteria.AddCondition(Tables.BusniessUnit.Name, ConditionOperator.Equal, docuTypeName);
                            EntityCollection buColl = service.RetrieveMultiple(buquery);

                            if (buColl.Entities.Count == 0)
                            {
                                tracingService.Trace("BU not found. Exit");
                            }

                            Guid buGuid = buColl.Entities[0].Id;

                            #endregion

                            #region Fetch the relevant role
                            // Fetch the relevant role
                            var rolesquery = new QueryExpression(Tables.SecurityRole.LogicalName);
                            rolesquery.ColumnSet.AddColumn(Tables.SecurityRole.PrimaryKey);
                            rolesquery.Criteria.AddCondition(Tables.BusniessUnit.PrimaryKey, ConditionOperator.Equal, buGuid);
                            rolesquery.Criteria.AddCondition(Tables.SecurityRole.Name, ConditionOperator.Equal, securityRoleName);

                            EntityCollection rolesColl = service.RetrieveMultiple(rolesquery);

                            if (rolesColl.Entities.Count == 0)
                            {
                                tracingService.Trace("Role not found. Exit");

                                return;
                            }

                            Guid roleId = rolesColl.Entities[0].Id;

                            tracingService.Trace("Role Id: " + roleId);
                            #endregion

                            #region Add the role to the team
                            try
                            {
                                if (context.MessageName == "Associate")
                                {
                                    service.Associate(
                                              Tables.Team.LogicalName,
                                              team.Id,
                                              new Relationship(Tables.Team.Relationship),
                                              new EntityReferenceCollection() { new EntityReference(Tables.SecurityRole.LogicalName, roleId) });

                                    tracingService.Trace("The role has been assigned to the team.");
                                }
                            }
                            catch
                            {
                                tracingService.Trace("Error occured while assigning the role.");
                            }

                            #endregion

                            #region Remove the role from the team
                            if (context.MessageName == "Disassociate")
                            {
                                service.Disassociate(
                                          Tables.Team.LogicalName,
                                          team.Id,
                                          new Relationship(Tables.Team.Relationship),
                                          new EntityReferenceCollection() { new EntityReference(Tables.SecurityRole.LogicalName, roleId) });

                                tracingService.Trace("The role has been assigned to the team.");
                            }
                            #endregion
                        }

                        #endregion
                    }
                }
            }
        }
    }
}
