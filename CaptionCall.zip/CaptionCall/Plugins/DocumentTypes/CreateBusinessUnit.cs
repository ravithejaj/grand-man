﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;

namespace Plugins.DocumentTypes
{

    public class CreateBusinessUnit : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            tracingService.Trace("Plugins.DocumentTypes.CreateBusinessUnit");         

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity currentRecord = (Entity)context.InputParameters["Target"];

                tracingService.Trace("Record Id [" + currentRecord.Id.ToString() + "]");

                #region Get the Root BU Guid
                var rbuquery = new QueryExpression(Tables.BusniessUnit.LogicalName);
                rbuquery.ColumnSet.AddColumn(Tables.BusniessUnit.PrimaryKey);
                rbuquery.Criteria.AddCondition(Tables.BusniessUnit.Name, ConditionOperator.Equal, Tables.BusniessUnit.RootBUName);

                EntityCollection BUCollection = service.RetrieveMultiple(rbuquery);

                if (BUCollection.Entities.Count == 0)
                {
                    tracingService.Trace("Root BU not found. Early Exit");

                    return;
                }

                Guid rootBUGuid = BUCollection.Entities[0].Id;

                tracingService.Trace("Root BU Guid: " + rootBUGuid);

                #endregion

                #region Create a new BU
                Entity record = new Entity(Tables.BusniessUnit.LogicalName);
                record[Tables.BusniessUnit.Name] = currentRecord[Tables.DocumentType.Name]; // Text
                record[Tables.BusniessUnit.ParentBU] = new EntityReference(Tables.BusniessUnit.LogicalName, rootBUGuid); // Lookup

                Guid buid = service.Create(record);

                tracingService.Trace("BU has been created: " + buid);
                #endregion

                #region Fetch the Team Guid
                var teamsquery = new QueryExpression(Tables.Team.LogicalName);
                teamsquery.ColumnSet.AddColumn(Tables.Team.PrimaryKey);
                teamsquery.Criteria.AddCondition(Tables.Team.Name, ConditionOperator.Equal, currentRecord[Tables.DocumentType.Name]);

                EntityCollection teamsColl = service.RetrieveMultiple(teamsquery);

                if (teamsColl.Entities.Count == 0)
                {
                    tracingService.Trace("Team not found. Exit");

                    return;
                }

                Guid teamGuid= teamsColl.Entities[0].Id;

                tracingService.Trace("Team Guid: " + teamGuid);

                #endregion

                #region Associate role to the team
                // Fetch the relevant role
                var rolesquery = new QueryExpression(Tables.SecurityRole.LogicalName);
                rolesquery.ColumnSet.AddColumn(Tables.SecurityRole.PrimaryKey);
                rolesquery.Criteria.AddCondition(Tables.BusniessUnit.PrimaryKey, ConditionOperator.Equal, buid);
                rolesquery.Criteria.AddCondition(Tables.SecurityRole.Name, ConditionOperator.Equal, Tables.SecurityRole.RoleName);

                EntityCollection rolesColl = service.RetrieveMultiple(rolesquery);

                if (rolesColl.Entities.Count == 0)
                {
                    tracingService.Trace("Role not found. Exit");

                    return;
                }

                Guid roleId = rolesColl.Entities[0].Id;

                tracingService.Trace("Role Id: " + roleId);
                #endregion

                #region Add the role to the team
                service.Associate(
                          Tables.Team.LogicalName,
                          teamGuid,
                          new Relationship(Tables.Team.Relationship),
                          new EntityReferenceCollection() { new EntityReference(Tables.SecurityRole.LogicalName, roleId) });

                tracingService.Trace("The role has been assigned to the team.");

                #endregion
            }
        }
    }
}