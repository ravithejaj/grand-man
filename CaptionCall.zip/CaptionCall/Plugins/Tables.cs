﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugins
{
    public class Tables
    {
        public class Relationships
        {
            public const string TeamRelationship = "new_new_documenttypeprivilegesconfi_team_NN";
            public const string UserRelationship = "businessunit";
        }
        public class BusniessUnit
        {
            public const string RootBUName = "Document Management";
            public const string LogicalName = "businessunit";
            public const string PrimaryKey = "businessunitid";
            public const string ParentBU = "parentbusinessunitid";
            public const string Name = "name";
        }
        public class DocumentType
        {
            public const string Name = "new_name";
            public const string PrimaryKey = "new_documenttypeid";
        }
        public class Team
        {
            public const string LogicalName = "team";
            public const string PrimaryKey = "teamid";
            public const string Name = "name";
            public const string Relationship = "teamroles_association";
        }

        public class DocumentUpload
        {
            public const string LogicalName = "new_documentupload";
            public const string PrimaryKey = "new_documentuploadid";
            public const string Name = "new_filename";
            public const string DocuTypeLookup = "new_documenttype";
            public const string Owner = "ownerid";
        }
        public class SecurityRole
        {
            public const string LogicalName = "role";
            public const string PrimaryKey = "roleid";
            public const string Name = "name";
            public const string RoleName = "Document Manager";
        }

        public class DocumentTypePrivilege
        {
            public const string LogicalName = "new_documenttypeprivilegesconfi";
            public const string PrimaryKey = "new_documenttypeprivilegesconfiid";
            public const string Name = "new_name";
            public const string SecurityRoleLookup = "new_securityrole";
            public const string DocumentTypeLookup = "new_documenttype";
        }
    }
}
