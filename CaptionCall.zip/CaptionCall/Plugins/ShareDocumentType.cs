﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;


namespace Plugins
{
    public class ShareDocumentType : IPlugin
    {
        public Guid docTypeConfigId = Guid.Empty;
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity currentRecord = (Entity)context.InputParameters["Target"];

                if (currentRecord.Contains("new_documenttype"))
                {
                    EntityReference documentType = currentRecord.GetAttributeValue<EntityReference>("new_documenttype");

                    // Fetch team GUIDs and privileges from the configuration record
                    List<KeyValuePair<Guid, AccessRights>> teamAndPrivileges = FetchTeamAndPrivilegesFromConfig(documentType.Id, service, tracingService);

                    // Share the contact record with teams with specified privileges
                    foreach (var teamPrivilege in teamAndPrivileges)
                    {
                        ShareRecord(new EntityReference(currentRecord.LogicalName, currentRecord.Id), teamPrivilege.Key, teamPrivilege.Value, service);
                    }
                }
                else
                {
                    tracingService.Trace("Document Type is blank. Early Exit");
                }

            }

        }

        /// <summary>
        /// Main function to fetch privileges and teams from the config record
        /// </summary>
        /// <param name="docTypeId"></param>
        /// <param name="service"></param>
        /// <param name="trace"></param>
        /// <returns></returns>
        private List<KeyValuePair<Guid, AccessRights>> FetchTeamAndPrivilegesFromConfig(Guid docTypeId, IOrganizationService service, ITracingService trace)
        {
            trace.Trace("Fn. FetchTeamAndPrivilegesFromConfig");

            List<KeyValuePair<Guid, AccessRights>> teamAndPrivileges = new List<KeyValuePair<Guid, AccessRights>>();

            Guid configId = Guid.Empty;

            var qrybyattr = new QueryByAttribute("new_documenttypeprivilegesconfi")
            {
                ColumnSet = new ColumnSet("new_privileges"),
                Attributes = { "new_documenttype" },
                Values = { docTypeId.ToString() }
            };

            EntityCollection retrievedColl = service.RetrieveMultiple(qrybyattr);

            if (retrievedColl.Entities.Count > 0)
            {
                configId = retrievedColl.Entities[0].Id;

                if (retrievedColl.Entities[0].Contains("new_privileges"))
                {
                    OptionSetValueCollection selectedOptions = (OptionSetValueCollection)retrievedColl.Entities[0]["new_privileges"];

                    AccessRights accessRights = AccessRights.None;

                    foreach (OptionSetValue selectedOptionValue in selectedOptions)
                    {
                        int optionValue = selectedOptionValue.Value;

                        if (Enum.IsDefined(typeof(AccessRights), optionValue))
                        {
                            accessRights |= (AccessRights)optionValue;
                        }
                    }

                    trace.Trace($"Access Rights: {accessRights}");

                    List<Guid> teamsGuids = GetTeamsFromConfig(configId, service, trace);

                    if (teamsGuids.Count <= 0)
                    {
                        trace.Trace("Teams are not configured. Returning empty teams list. Early Exit");

                        return teamAndPrivileges;
                    }

                    foreach (Guid teamGuid in teamsGuids)
                    {
                        teamAndPrivileges.Add(new KeyValuePair<Guid, AccessRights>(teamGuid, accessRights));
                    }

                }
                else
                {
                    trace.Trace("Privileges is not set. Returning empty teams list. Early Exit");

                    return teamAndPrivileges;
                }
            }

            else
            {

                trace.Trace("Config is not found. Returning empty teams list. Early Exit");

                return teamAndPrivileges;

            }

            return teamAndPrivileges;
        }

        /// <summary>
        /// Sub.Function to fetch teams from the config record
        /// </summary>
        /// <param name="configId"></param>
        /// <param name="service"></param>
        /// <param name="trace"></param>
        /// <returns></returns>
        private List<Guid> GetTeamsFromConfig(Guid configId, IOrganizationService service, ITracingService trace)
        {
            trace.Trace("Fn. GetTeamsFromConfig");

            List<Guid> teamsGuid = new List<Guid>();

            // Query teams from the config record
            var query = new QueryExpression("team");
            query.ColumnSet.AddColumns("name", "teamid");
            var query_new_documenttypeprivilegesconfi = query.AddLink(
                "new_documenttypeprivilegesconfi",
                "new_documenttypeconfigid",
                "new_documenttypeprivilegesconfiid");

            query_new_documenttypeprivilegesconfi.LinkCriteria.AddCondition("new_documenttypeprivilegesconfiid", ConditionOperator.Equal, configId);

            EntityCollection teamsCollection = service.RetrieveMultiple(query);

            if (teamsCollection.Entities.Count > 0)
            {
                foreach (Entity team in teamsCollection.Entities)
                {
                    teamsGuid.Add(team.Id);
                }
            }
            else
            {
                trace.Trace("No Teams are associated with the config record.");
            }

            trace.Trace("No. of Teams: " + teamsGuid.Count);

            return teamsGuid;

        }

        /// <summary>
        /// Main function to share the record with teams
        /// </summary>
        /// <param name="recordRef"></param>
        /// <param name="principalId"></param>
        /// <param name="accessRights"></param>
        /// <param name="service"></param>
        private void ShareRecord(EntityReference recordRef, Guid principalId, AccessRights accessRights, IOrganizationService service)
        {
            var share = new GrantAccessRequest
            {
                PrincipalAccess = new PrincipalAccess
                {
                    // Determine whether the principal is a user or a team
                    Principal = new EntityReference("team", principalId),
                    AccessMask = accessRights
                },
                Target = recordRef
            };

            service.Execute(share);
        }
    }
}
